This resource pack is for Minecraft version 1.14.4.

At your first setup steps are:

1. Open the game.

2. Go to "Options...".

3. Then, open "Resource Packs..."

4. Click "Open Resource Pack Folder" and wait.

5. Copy Aksupack's zip file to opened folder and close folder.
(Do not extract the .zip-file.)

6. Click "Done", then open "Resource Packs..." again.

7. Click "Aksupack" and click "Done".

8. Aksupack is loaded now for game. Enjoy!

Quick FAQ

* What is Resource pack's license?

< CC Attribution-NonCommercial-NoDerivatives 4.0 International
< Link: https://creativecommons.org/licenses/by-nc-nd/4.0/ 
< (License is included in zip file, read "License.txt". Do not extract the .zip-file.)
< You will need read "TERMSOFUSE.txt".

* Who made this pack?

< Aksu Lightning

* Is reupload allowed?

< No. Read "TERMSOFUSE.txt" for more information.

* It works?

< Yes, works also in old computers and newer "Intel Atom" -based tablets and computer sticks.

* Can I make videos with this resource pack?

< Yes, you can, as long as your video and links are non-profit: "your video is ad-free, no ad-links in description, not making money from video". 

< Youtube and Dailymotion is allowed.

* Then, new version is coming?

< Time is needed, it does not come by itself.

